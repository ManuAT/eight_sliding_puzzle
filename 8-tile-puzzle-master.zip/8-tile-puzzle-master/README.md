<h1>8 Tile Puzzle</h1>

<p>This project is a playable 8 tile puzzle. It is written in Javascript and is playable in the browser.</p>
<p>I used the A* search algorithm to solve the puzzle with the guidance of the Manhattan Distance heuristic. The project also includes a one time hint, a constant answer notification, and an automatic solver. The auto solver visually shows how to solve each puzzle. Just by watching it I've already gotten much more efficient at doing the puzzle.</p>
<p>You can see the project live <a href="http://www-scf.usc.edu/~smoran/8tile.html">here</a>.</p>